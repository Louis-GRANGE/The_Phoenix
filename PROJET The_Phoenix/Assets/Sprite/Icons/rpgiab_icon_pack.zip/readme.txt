Justin's 16x16 Icon Pack (v1.0)

Created by Justin Arnold
https://zeromatrix.itch.io/rpgiab-icons
E-mail: justin@rpginabox.com

This 16x16 icon pack contains 218 colorful, application-oriented icons.
These were created specifically for the upcoming version of RPG in a Box (https://www.rpginabox.com) set to be released next year.
(Check out the engine if you're interested in creating your own grid-based, voxel-style RPGs and adventure games!)

If you'd like to see any specific icons added to this set, please let me know and I'll see what I can do.
These icons are released under the CC BY 4.0 license, so you are free to use or modify them in any manner. Credit would be very much appreciated! :)

If you do use them for anything, let me know as I'd love to see it!

---

This work is licensed under the Creative Commons Attribution 4.0 International License.
To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/
or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.
